<style type="text/css">
	.navbar_fixed .main_menu .container .navbar .navbar-brand span{

		color: #029e91 !important;
	}

	.header_area.navbar_fixed.white_header .main_menu .navbar .navbar-brand img{

		display: inline;
	}

	#choose_lang:hover{
		color: #58547e !important;
		cursor: inherit;
	}

</style>
<header class="header_area white_header">
<!-- <ul class="nav menu_social flex-column">
<li>
<a href="#"><i class="fab fa-facebook"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-twitter"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-instagram"></i></a>
</li>
</ul> -->
<div class="main_menu">
<div class="container">
<nav class="navbar navbar-expand-lg navbar-light bg-light">

<span class="notranslate" id="header_logo">

</span>


<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="nav navbar-nav ml-auto notranslate" id="header_links">


</ul>
<ul class="nav navbar-nav navbar-right">
<!-- <li class="checker_btn">
<a href="#"><i class="linearicons-pulse"></i> Symptom Checker</a>
</li> -->
<li class="checker_btn" style="margin-left: -20px;">

	
	<a  id="bengali_btn" href="../symptom-checker"><!-- <i class="linearicons-pulse"></i> --> BENGALI</a>

</li>
</ul>
</div>
</nav>
</div>
<div class="right_burger">
<ul class="nav">
<li>
<div class="search_btn" data-toggle="modal" data-target="#exampleModal">
<!-- <img id="search_header" src="assets/images/icon/search-white.png" alt="" /> -->
<ul class="nav navbar-nav navbar-right" id="mbl_lang" style="display: none;">
<li class="checker_btn" style="margin-left: -40px;margin-top:0px">
	
	
	<a id="bengali_btn1" href="../symptom-checker"  style="background: #01cfbe !important;padding: 5px;border-radius: 4px;color: white;font-size: 12px;"><!-- <i class="linearicons-pulse"></i> --> BENGALI</a>

</li>
</ul>
</div>
</li>
<li>
<div class="menu_btn" id="header_menu_bar1" style="display: none;">
<img src="assets/images/icon/burger-white.png" alt="covidsurokkha" />
</div>
</li>
</ul>
</div>
<?php include 'header_scroll_indicator.php';?>
</div>
</header>

