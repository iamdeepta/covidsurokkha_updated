<style type="text/css">
	@media screen and (max-width: 460px){
		.not_feeling_well_text{
			font: 700 16px/26px "Quicksand",sans-serif !important;
		}
	}
</style>
<?php 

if(isset($_POST['top_text'])){

  $output = '';




  $output .= '<p class="not_feeling_well_text" style="font:700 18px quicksand,sans-serif;color: #01cfbe;">You are not feeling well?</p>

<h3>Coronavirus Symptom Checker</h3>

<div class="nav justify-content-center" style="text-align: center;"><div style="width: 50%;height: 5px;background-color: lightgray;border-radius: 6px"><div id="progress_bar" style="width: 20%;background-color: #01cfbe;color: #01cfbe;height: 5px;border-radius: 6px"></div></div></div>';





echo $output;

}


?>

<!-- <ul class="nav justify-content-center">
<li><a href="index.html">Home</a></li>
<li><a href="prevention.html">Prevention</a></li>
<li><a href="checker.html">Symptom Checker</a></li>
</ul> -->


<!-- <div class="row">
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-lifebuoy"></i>
</div>
<div class="media-body">
<h4>We help you</h4>
<p>Our experts gives you advice</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-finger-tap"></i>
</div>
<div class="media-body">
<h4>Easy to use</h4>
<p>4 steps, it’s quite simple</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-tags"></i>
</div>
<div class="media-body">
<h4>100% FREE</h4>
<p>Don’t worry about the cost</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-bubble-question"></i>
</div>
<div class="media-body">
<h4>Got questions?</h4>
<p>Contact us, we answer you</p>
</div>
</div>
</div>
</div> -->

<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->


<!-- <div class="radio_btn">
<h5>What’s your gender?</h5>
<div class="select_conversation">
<input type="radio" name="male" id="male" value="male">
<label for="male">Male</label>
</div>
<div class="select_conversation">
<input type="radio" name="male" id="female" value="female">
<label for="female">Female</label>
</div>
</div> -->
<!-- <select class="nice_select checker_select">
<option value="1">Select your Region</option>
<option value="2">Islam</option>
<option value="3">Islam</option>
</select> -->

<!-- <select class="nice_select checker_select">
<option value="1">What’s your age?</option>
<option value="2">25</option>
<option value="3">26</option>
</select> -->


<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->

<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->

<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->
