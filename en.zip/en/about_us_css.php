<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<!-- <link rel="preload" href="assets/css/bootstrap.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
<noscript><link rel="stylesheet" href="assets/css/bootstrap.min.css"></noscript> -->
<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.css" />
<!-- <link rel="preload" href="assets/vendors/fontawesome/css/all.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
<noscript><link rel="stylesheet" href="assets/vendors/fontawesome/css/all.css"></noscript> -->
<!-- <link rel="stylesheet" href="assets/vendors/linearicons/css/linearicons.css" /> -->
<link rel="stylesheet" href="assets/vendors/slick/slick.css" />
<link rel="stylesheet" href="assets/vendors/slick/slick-theme.css" />
<!-- <link rel="stylesheet" href="assets/vendors/mCustomScrollbar/jquery.mCustomScrollbar.min.css" /> -->
<!-- <link rel="stylesheet" href="assets/vendors/animate-css/animate.css" /> -->
<!-- <link rel="preload" href="assets/vendors/animate-css/animate.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
<noscript><link rel="stylesheet" href="assets/vendors/animate-css/animate.css"></noscript> -->

<link rel="stylesheet" href="assets/css/style.css" />
<!-- <link rel="preload" href="assets/css/style.css" as="style" onload="this.onload=null;this.rel='stylesheet'" /> -->
<!-- <link rel="preload" href="assets/css/style.css" as="style" onload="this.onload=null;this.rel='stylesheet'" /> -->
<!-- <noscript><link rel="stylesheet" href="assets/css/style.css"></noscript> -->

<link rel="stylesheet" href="assets/css/responsive.css" />
<!-- <link rel="preload" href="assets/css/responsive.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
<noscript><link rel="stylesheet" href="assets/css/responsive.css"></noscript> -->


<!-- <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  /> -->

   <!-- <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
   <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"></noscript> -->


<style type="text/css">

	body{

		top: 0px !important;
	}

	::-webkit-scrollbar-thumb{

		background: #01cfbe !important;
	}

	/*table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after, table.dataTable thead .sorting_asc_disabled:after, table.dataTable thead .sorting_desc_disabled:after{

		content: none !important;
	}*/

	

	/*#dtBasicExample::after{

		content: 'Data source: DHIS2    Technical assistance by: UNICEF' !important;
		width: 100% !important;
		background-color: 
	}*/

	.goog-te-banner-frame{

		visibility: hidden !important;
		display: none !important;
	}

	.page-item.active .page-link{

		background-color: #58547e !important;
		border-color: #58547e !important;
		color: white !important;

	}

	.page-link{

		color: #58547e !important;
	}

	
	
	::placeholder{

		float: right !important;
		margin-top: 10px !important;
		font-size: 14px !important;
	}

	

	.p_100{

		padding-bottom: 25px !important;
	}



	@media screen and (max-width: 460px) {

		::-webkit-scrollbar-thumb{

		background: #01cfbe !important;
	}




	.mobile_canvus_menu .menu_part_lux .menu_list li a i{

		position: inherit !important;
	}

	.mobile_canvus_menu .menu_part_lux .menu_list li a.open i{

		transform: rotate(0deg) !important;
		color: #01cfbe !important;
	}

	

	#covidshebalogos{

		height: 40px !important;
		width: 200px !important;
		/*margin-top: -3px !important;*/
	}

	#covidshebalogos_bangla{

		height: 28px !important;
		width: 157px !important;
		/*margin-top: -3px !important;*/
	}

	#covidlogo{

		font-size: 24px !important;
	}

	
	#header_menu_bar{

		display: block !important;
	}
  
		

		#footer_section{

			margin-top: 0px !important;
		}

		#discount_text{

		width: 57% !important;
		margin-left: -30px !important;

		}

		#afialogo{

			width: 25% !important;
		}

		.footer_widgets_area .row{

			margin-top: -15px !important;
			margin-bottom: -10px !important;
		}

		#footer_part1{

			margin-bottom: 0px !important;
		}

		#footer_part3{

			margin-bottom: 0px !important;
		}

		

		#mbl_lang{

			display: block !important;
		}

		#search_header{

			display: none !important;
		}

		

		::placeholder{

		
		margin-top: 0px !important;
		font-size: 10px !important;
		float: inherit !important;
		color: gray !important;
		
	}
	

	



	.main_menu .navbar .navbar-brand{

		line-height: 50px !important;
	}

	.right_burger{

		top: 42px !important;
	}

	

		
}




</style>