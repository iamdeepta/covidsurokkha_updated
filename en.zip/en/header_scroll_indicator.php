<div class="progress" style="height: 6px; background-color: transparent;width: 100%;">
  <div class="progress__highlight" id="bar-highlight" style="transition: width 0.15s linear;background-color: #01cfbe;height: 100%;width: 0%"></div>
</div>